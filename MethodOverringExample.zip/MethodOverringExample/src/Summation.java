
public class Summation extends Addition {

	public void add(int a, int b) {
		System.out.println((a - (-b)));
	}
}
