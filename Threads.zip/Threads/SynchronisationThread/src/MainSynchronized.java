
class MainSynchronized {
	public static void main(String[] args) {
		Thread1 obj = new Thread1();
		Thread2 thread2 = new Thread2(obj);
		Thread3 thread3 = new Thread3(obj);
		Thread3 thread4 = new Thread3(obj);
		Thread3 thread5 = new Thread3(obj);
		Thread3 thread6 = new Thread3(obj);
		thread2.start();
		thread3.start();
		thread4.start();
		thread5.start();
		thread6.start();
	}
}