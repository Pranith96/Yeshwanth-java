package com.demo.hello;

public class Hello1 {

	private void hi() {
		System.out.println("HII!!");
	}

	public void display() {
		System.out.println("display");
	}

	void display2() {
		System.out.println("display");
	}
}
