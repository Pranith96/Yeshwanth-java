
public class Calculator extends Summation {

	public void mul() {
		System.out.println("Mul");
	}

	public void div() {
		System.out.println("DIV");
	}
}
