
public class AdditionImpl implements Addition, Summation {

	@Override
	public void add() {
		System.out.println("ADD");
	}

	@Override
	public void sub() {
		System.out.println("ADD");
	}

	@Override
	public void mul() {
		System.out.println("MUL");
	}

	@Override
	public void div() {
		System.out.println("DIV");
	}

	@Override
	public void hello() {
		System.out.println("Hello");
	}

}
