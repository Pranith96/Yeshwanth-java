
public class Subtraction extends Addition{

	public void sub() {
		System.out.println("Subtract");
	}
}
