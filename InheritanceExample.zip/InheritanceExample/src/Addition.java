public class Addition {

	public void add(int a, int b) {
		int c = 5;
		System.out.println("Add: " + (a + b)); // 7
		System.out.println(a + " " + b + " " + c); // 345
		System.out.println("Add: " + (a + b + c)); // 12
	}
}
