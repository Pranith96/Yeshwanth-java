
public class MainMethod {

	public static void main(String[] args) {

		Summation sum = new Summation();
		sum.add(2, 4);

		Addition add = new Addition();
		add.add(2, 5);
	}
}
