package com.demo.hello;

import com.demo.demo.Print;

public class Hello{

	public static void main(String[] args) {
		Hello1 hello = new Hello1();
		hello.display();

		Print print = new Print();
		print.display1();
	}

}
