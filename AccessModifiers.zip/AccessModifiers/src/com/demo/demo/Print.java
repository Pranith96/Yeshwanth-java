package com.demo.demo;

public class Print {
	
	public void display1() {
		System.out.println("display1");
	}
	
	protected void demo1() {
		System.out.println("Demo1");
	}

}
