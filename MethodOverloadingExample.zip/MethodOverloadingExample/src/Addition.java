
public class Addition {
//method overloading
	public void add(int a, int b) {
		System.out.println("Add: " + (a + b));
	}

	public void add(int a, int b, int c) {
		System.out.println("add: " + (a + b + c));
	}
}
