
public interface Summation {

	public void add();

	public void sub();

	public void mul();

	public void div();

	public void hello();

}
