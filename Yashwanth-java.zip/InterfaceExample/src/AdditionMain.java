import java.util.Scanner;

public class AdditionMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scanner sc = new Scanner(System.in);
//
//		int a = sc.nextInt();
//		String b = sc.next();
//		String c = sc.nextLine();
		
		AdditionImpl add = new AdditionImpl();
		add.add();
		add.div();
		add.hello();
		add.mul();
		add.sub();
	}
}
