
public abstract class Summation extends Addition {

	public void add() {
		System.out.println("ADD");
	}

	public void sub() {
		System.out.println("SUB");
	}
	
	public abstract void mul();
	public abstract void div();

}
