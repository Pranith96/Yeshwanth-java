
public interface Addition1 extends Addition{

	public void display();
}
