
public class CalculatorMain {

	public static void main(String[] args) {

		Calculator calc = new Calculator();
		calc.add();
		calc.hello();
		calc.mul();
		calc.sub();
	}
}
