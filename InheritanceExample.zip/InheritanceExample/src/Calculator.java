
public class Calculator {

	public static void main(String[] args) {

		Subtraction subtraction = new Subtraction();
		subtraction.sub();
		subtraction.add(3, 4);
	}
}
