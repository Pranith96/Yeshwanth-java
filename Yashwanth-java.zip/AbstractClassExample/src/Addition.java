
public abstract class Addition {

	public abstract void add();

	public abstract void sub();

	public void hello() {
		System.out.println("Hello");
	}
}
