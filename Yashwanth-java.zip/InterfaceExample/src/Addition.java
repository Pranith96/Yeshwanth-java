
public interface Addition {
	public void add();

	public void sub();

	public void mul();

	public void div();
	
	public void hello();
}
