import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

// need to check for nullcheck when both maps data is different
public class RansomNotes {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		String ransomNote = sc.nextLine();
		ransomNote = ransomNote.replaceAll("\\s", "");
		Map<Character, Integer> ransomMap = mapMethod(ransomNote);
		System.out.println(ransomMap);

		String magazine = sc.nextLine();
		magazine = magazine.replaceAll("\\s", "");
		Map<Character, Integer> magazineMap = mapMethod(magazine);
		System.out.println(magazineMap);

		boolean data = false;

		for (Character k : ransomMap.keySet()) {
			if (ransomMap.get(k) > 0 && magazineMap.get(k) > 0) {
				if (magazineMap.get(k) >= ransomMap.get(k)) {
					data = true;
				} else {
					data = false;
				}
			}
		}
		System.out.println(data);
		sc.close();
	}

	private static Map<Character, Integer> mapMethod(String data) {
		Map<Character, Integer> mapData = new LinkedHashMap<>();

		for (int i = 0; i < data.length(); i++) {

			if (!mapData.containsKey(data.charAt(i))) {
				mapData.put(data.charAt(i), 1);
			} else {
				mapData.put(data.charAt(i), mapData.get(data.charAt(i)) + 1);
			}
		}

		return mapData;
	}
}
